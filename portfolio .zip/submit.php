<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect and sanitize input data
    $name = htmlspecialchars(trim($_POST['name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $message = htmlspecialchars(trim($_POST['message']));

    // Prepare email parameters
    $to = 'marvinmunene254@gmail.com'; // Replace with your email address
    $subject = 'New Contact Form Submission';
    
    // Construct email body
    $body = "Name: $name\nEmail: $email\n\nMessage:\n$message";
    
    // Set headers
    $headers = "From: $email";

    // Send email
    if (mail($to, $subject, $body, $headers)) {
        echo "Message sent successfully!";
    } else {
        echo "Failed to send message.";
    }
} else {
    echo "Invalid request.";
}
