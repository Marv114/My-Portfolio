console.log("Welcome to my portfolio!");
// Get references to the DOM elements
document.getElementById('contactForm').addEventListener('submit', function(event) {
  const name = document.getElementById('name').value;
  const email = document.getElementById('email').value;

  if (!name || !email) {
    alert('Please fill in all fields.');
    event.preventDefault(); // Prevent form submission
  } else {
    alert(`Thank you for your message, ${name}!`);
  }
});
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    e.preventDefault();
    document.querySelector(this.getAttribute('href')).scrollIntoView({
      behavior: 'smooth'
    });
  });
});
// Get the lightbox element
const lightbox = document.getElementById('lightbox');
const lightboxImg = document.getElementById('lightbox-img');
const closeBtn = document.querySelector('.close');

// Get all images with the 'gallery-image' class
const images = document.querySelectorAll('.gallery-image');

// Add click event listener to each image
images.forEach(image => {
  image.addEventListener('click', () => {
    lightbox.style.display = 'block';
    lightboxImg.src = image.src; // Set the lightbox image source to the clicked image
  });
});

// Close the lightbox when the close button is clicked
closeBtn.addEventListener('click', () => {
  lightbox.style.display = 'none';
});

// Close the lightbox when clicking outside the image
lightbox.addEventListener('click', (event) => {
  if (event.target !== lightboxImg) {
    lightbox.style.display = 'none';
  }
});